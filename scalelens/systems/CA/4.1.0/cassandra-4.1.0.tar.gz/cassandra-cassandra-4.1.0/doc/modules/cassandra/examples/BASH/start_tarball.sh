$ cd apache-cassandra-4.0.0/ && bin/cassandra
