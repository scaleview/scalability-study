$ tar xzvf apache-cassandra-4.0.0-bin.tar.gz
