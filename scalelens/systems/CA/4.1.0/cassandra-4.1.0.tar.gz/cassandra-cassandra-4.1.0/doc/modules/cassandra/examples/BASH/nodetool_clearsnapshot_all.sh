$ nodetool clearsnapshot -all cqlkeyspace
