$ nodetool status
