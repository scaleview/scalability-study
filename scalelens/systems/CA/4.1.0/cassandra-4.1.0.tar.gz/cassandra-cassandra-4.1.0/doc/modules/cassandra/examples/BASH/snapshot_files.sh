$ cd catalog-ks && ls -l
