$ cqlsh
