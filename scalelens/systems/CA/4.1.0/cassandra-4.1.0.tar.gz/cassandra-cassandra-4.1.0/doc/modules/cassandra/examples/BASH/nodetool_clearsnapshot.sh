$ nodetool clearsnapshot -t magazine cqlkeyspace
