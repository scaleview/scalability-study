$ curl https://downloads.apache.org/cassandra/KEYS | sudo apt-key add -
