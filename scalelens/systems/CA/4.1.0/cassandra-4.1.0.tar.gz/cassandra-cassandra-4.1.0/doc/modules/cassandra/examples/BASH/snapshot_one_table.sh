$ nodetool snapshot --tag <tag> --table <table>  --<keyspace>
