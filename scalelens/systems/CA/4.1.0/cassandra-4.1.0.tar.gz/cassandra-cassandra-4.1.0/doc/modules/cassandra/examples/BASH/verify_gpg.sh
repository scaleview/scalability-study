$ gpg --print-md SHA256 apache-cassandra-4.0.0-bin.tar.gz
