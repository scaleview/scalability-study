$ find -name backups
