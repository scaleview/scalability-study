$ nodetool help snapshot
