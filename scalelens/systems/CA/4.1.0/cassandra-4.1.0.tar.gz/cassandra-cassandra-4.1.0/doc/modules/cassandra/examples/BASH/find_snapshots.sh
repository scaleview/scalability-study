$ find -name snapshots
