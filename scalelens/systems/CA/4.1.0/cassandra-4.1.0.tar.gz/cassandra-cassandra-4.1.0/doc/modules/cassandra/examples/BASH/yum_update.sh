$ sudo yum update
