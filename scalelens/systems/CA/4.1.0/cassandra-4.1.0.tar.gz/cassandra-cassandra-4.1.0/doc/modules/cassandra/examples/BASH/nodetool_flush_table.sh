$ nodetool flush cqlkeyspace t
