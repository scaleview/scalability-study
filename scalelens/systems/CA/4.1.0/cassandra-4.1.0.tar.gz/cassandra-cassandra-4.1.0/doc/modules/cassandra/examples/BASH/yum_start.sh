$ sudo service cassandra start
