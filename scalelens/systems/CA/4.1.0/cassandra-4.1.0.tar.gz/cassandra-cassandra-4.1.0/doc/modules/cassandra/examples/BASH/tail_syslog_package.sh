$ tail -f /var/log/cassandra/system.log
