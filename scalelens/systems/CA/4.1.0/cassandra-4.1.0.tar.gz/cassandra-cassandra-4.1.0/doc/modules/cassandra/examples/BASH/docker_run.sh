docker run --name cass_cluster cassandra:latest
