$ bin/cqlsh
