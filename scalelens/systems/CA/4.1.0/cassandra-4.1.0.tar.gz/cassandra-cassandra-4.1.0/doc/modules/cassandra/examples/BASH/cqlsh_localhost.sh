$ bin/cqlsh localhost
