docker pull cassandra:latest
