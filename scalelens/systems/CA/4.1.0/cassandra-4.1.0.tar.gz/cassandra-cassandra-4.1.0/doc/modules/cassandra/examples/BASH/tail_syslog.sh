$ tail -f logs/system.log
