docker exec -it cass_cluster cqlsh
