$ sudo yum install cassandra
