$ sudo apt-get install cassandra
