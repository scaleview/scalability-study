$ sudo apt-get update
