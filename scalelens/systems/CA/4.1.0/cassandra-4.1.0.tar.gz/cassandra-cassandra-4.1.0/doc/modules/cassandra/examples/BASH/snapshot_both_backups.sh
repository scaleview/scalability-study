$ nodetool snapshot --tag catalog-cql-ks catalogkeyspace, cqlkeyspace
