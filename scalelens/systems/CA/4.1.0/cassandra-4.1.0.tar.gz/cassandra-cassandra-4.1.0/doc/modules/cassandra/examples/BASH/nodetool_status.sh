$ bin/nodetool status
