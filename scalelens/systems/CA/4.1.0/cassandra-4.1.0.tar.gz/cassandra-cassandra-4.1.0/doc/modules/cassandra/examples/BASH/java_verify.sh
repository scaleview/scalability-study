$ java -version
