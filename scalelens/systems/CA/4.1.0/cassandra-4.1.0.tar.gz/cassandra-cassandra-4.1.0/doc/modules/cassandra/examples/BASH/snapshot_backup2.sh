$ nodetool snapshot --tag catalog-ks catalogkeyspace
