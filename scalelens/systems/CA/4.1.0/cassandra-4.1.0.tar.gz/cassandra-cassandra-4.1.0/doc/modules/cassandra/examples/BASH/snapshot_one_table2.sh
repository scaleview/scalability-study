$ nodetool snapshot --tag magazine --table magazine  catalogkeyspace
