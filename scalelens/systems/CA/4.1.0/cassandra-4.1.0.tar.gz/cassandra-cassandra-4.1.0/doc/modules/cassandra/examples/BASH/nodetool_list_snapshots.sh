$ nodetool listsnapshots
